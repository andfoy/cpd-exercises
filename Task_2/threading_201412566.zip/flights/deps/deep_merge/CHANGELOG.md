## 0.2.0 (2018-07-27)

* Remove compile warnings on elixir 1.7
* Remove 1.2 from the build matrix (was getting big, should still work)

## 0.1.1 (2016-11-29)

* Remove warnings when run with elixir 1.4.0-rc.0
