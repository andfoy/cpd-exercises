# LifeCLI

**TODO: Add description**

## Installation

If [available in Hex](https://hex.pm/docs/publish), the package can be installed
by adding `life_cli` to your list of dependencies in `mix.exs`:

```elixir
def deps do
  [
    {:life_cli, "~> 0.1.0"}
  ]
end
```

Documentation can be generated with [ExDoc](https://github.com/elixir-lang/ex_doc)
and published on [HexDocs](https://hexdocs.pm). Once published, the docs can
be found at [https://hexdocs.pm/life_cli](https://hexdocs.pm/life_cli).

